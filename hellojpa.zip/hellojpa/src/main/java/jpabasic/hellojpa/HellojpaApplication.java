package jpabasic.hellojpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellojpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellojpaApplication.class, args);
	}

}
